Easy Email

Send emails in Python!